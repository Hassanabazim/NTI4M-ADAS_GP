#ifndef _HDC_MOTOR_
#define _HDC_MOTOR_



/*Directional Motor pins */
#define Diriction_Motor_CW			PIN4
#define Diriction_Motor_ANTI_CW		PIN5


/* Forward and back motor Pins*/
#define DC1_M_F			PIN2

#define DC1_M_B 		PIN3

#endif
